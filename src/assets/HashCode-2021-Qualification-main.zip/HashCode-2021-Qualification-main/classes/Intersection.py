class Intersection:
    def __init__(self, id, nrIncomingStreets, incomingStreets, outgoingStreets):
        self.id = id
        self.nrIncomingStreets = nrIncomingStreets
        self.incomingStreets = incomingStreets
        self.outgoingStreets = outgoingStreets
