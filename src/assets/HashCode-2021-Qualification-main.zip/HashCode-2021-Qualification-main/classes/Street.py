class Street:
    def __init__(self, id, origin, finish, length, traffic_light_green):
        self.id = id
        self.origin = origin
        self.finish = finish
        self.length = length
        self.traffic_light_greens = traffic_light_green
