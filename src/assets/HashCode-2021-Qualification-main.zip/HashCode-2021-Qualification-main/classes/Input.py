class Input:
    def __init__(self, cars, streets, traffic_lights, intersections):
        self.cars = cars
        self.streets = streets
        self.traffic_lights = traffic_lights
        self.intersections = intersections
