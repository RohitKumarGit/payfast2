class Schedule:
    def __init__(self, intersection_id, numIncomingStreets, street_time):
        self.intersection_id = intersection_id
        self.numIncomingStreets = numIncomingStreets
        self.street_time = street_time #Dictionary?
