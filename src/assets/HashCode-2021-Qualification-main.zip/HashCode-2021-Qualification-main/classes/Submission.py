class Submission:
    def __init__(self, numIntersections, schedules):
        self.numIntersections = numIntersections
        self.schedules = schedules
