# HashCode-2021-Qualification
Team Jointify is back at it again and wants. toclaim the HashCode 2021 Munich Hub crown
